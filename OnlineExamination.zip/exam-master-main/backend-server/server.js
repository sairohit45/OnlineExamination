/**
 * MySQL Backend Server for Online Exam - Aiven Cloud Database
 * 
 * DEPLOYMENT ON RENDER:
 * 1. Create a new Web Service on Render
 * 2. Connect your GitHub repository
 * 3. Set the root directory to "backend-server"
 * 4. Build Command: npm install
 * 5. Start Command: node server.js
 * 6. The server will run on the port provided by Render
 */

const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Aiven MySQL Connection Configuration
const dbConfig = {
  host: 'mysql-exam-database-examproject45.i.aivencloud.com',
  port: 19935,
  user: 'avnadmin',
  password: 'AVNS_oVtBLA-wbkBkNDj1v7u',
  database: 'exam_db',
  ssl: {
    ca: `-----BEGIN CERTIFICATE-----
MIIEUDCCArigAwIBAgIULCTRqlE9nm3ujxzv4u88Wl/catowDQYJKoZIhvcNAQEM
BQAwQDE+MDwGA1UEAww1NjgxMDRkY2EtZjhjMS00MTBkLTkyNTgtNmIwODkzNGFl
NzZiIEdFTiAxIFByb2plY3QgQ0EwHhcNMjUxMjI0MTc1NDUzWhcNMzUxMjIyMTc1
NDUzWjBAMT4wPAYDVQQDDDU2ODEwNGRjYS1mOGMxLTQxMGQtOTI1OC02YjA4OTM0
YWU3NmIgR0VOIDEgUHJvamVjdCBDQTCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCC
AYoCggGBALzN7nz/+LOXOOltvGPg/dAiHQYw7YF2o5xEPY50jLmsMv2RnL6F4kWZ
OHcXJ6/elYBQYaWks2Z+YjhlIuPS4psDjaJ0vu0ELBmv9q1Pa7daLXl8g2HDSOZe
aY4+T7M9brMRez3xKPvT+ZrVopcb9Ft0WmcoijtqXJmAzcrCFXjIKFMWUhIBPszi
VMccmohqJvbb2IJEZdPL1po58myLzmyxLWNAeY1/2kGHe0S2wrHvhXTBTx+/Rb3F
MOxuJ2W/dB3Wo7UK7sIivP6RcXc60bVb+X2wQIrraX+9zLGWJfCiDr3UYNkrCnpu
vyp8Hle5Nb7GRJ0ZNvbDsgJeq9eaZPhTxDgeHfyCf6XDU3eLxTAb0tpF24kJWOXl
qauhPbJ3ubEpJuchfo0cWbv2D9Q/5I3t8STaoF76si201NEi0HqwSsM344/XYVQ+
3cPY4L8tfdmx4Rla/AVFhR2lQue9L+VMivA6Ryr9qhhWmv8iIc8y7ugVWxS6Epxx
Y1EycTuwmQIDAQABo0IwQDAdBgNVHQ4EFgQU+gV6quUQgnaDDXGRijL9y9bMiwUw
EgYDVR0TAQH/BAgwBgEB/wIBADALBgNVHQ8EBAMCAQYwDQYJKoZIhvcNAQEMBQAD
ggGBAHwKArtuZlF8BW4D3Kt3StpI634U6DajlLWxRBi+zS4ZkiEm6W4mVuOIQk8g
Utzy6GHCUGS3XQUFbZk0JzaWPOs0RwhpX5qFTm54TLbRO2jjg9+2fjmCSgrOTMrb
FD4lYubI8vAAdmvq7qrLQyFi4RQb3kfPl6gA097zvlpk1vgqIW+HKcBFRTchikxh
iE0pCCKtICA3cK+PF4jK1Xq+jQZTHaiyyzcuZcS9pVb/9r1KgvqMGu6R+wbByDhw
USf8ECCsQn1XYY6AmdXwpA7PKfxGgk0c15uJTzcnEqoLkeT8wsC1VqsfquI/2CZh
ghT1ciZm8feZSmhS0E913I92/ZF+6ivLbQwXuGdD9cbFrjjBhltb9cl+PWff2o4+
j8CPjQPTxyu7dPbYQnnRo8uI/wI6LSjS8aTvyUeB5+bx3IKm+GZYl1vEI0p3Ipgc
IImHx/5GxihNC/jH8E1juPsuyVAIKxLTbzB+Y6TJVheaplelIOSLvGI3HAcIwE5C
Dl5xmw==
-----END CERTIFICATE-----`,
    rejectUnauthorized: true
  }
};

// Create MySQL connection pool
const pool = mysql.createPool(dbConfig);

// Test database connection
app.get('/api/test', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT 1 as result');
    res.json({ success: true, message: 'Database connected successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Health check for Render
app.get('/', (req, res) => {
  res.json({ status: 'OK', message: 'Exam Server is running!' });
});

// Submit exam response
app.post('/api/submit-exam', async (req, res) => {
  try {
    const {
      roll_number,
      name,
      department,
      section,
      score,
      total_questions,
      was_tab_switched,
      submitted_at
    } = req.body;

    const query = `
      INSERT INTO exam_responses 
      (roll_number, name, department, section, score, total_questions, was_tab_switched, submitted_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await pool.execute(query, [
      roll_number,
      name,
      department,
      section,
      score,
      total_questions,
      was_tab_switched,
      submitted_at || new Date()
    ]);

    res.json({ success: true, message: 'Exam submitted successfully!' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      res.status(400).json({ success: false, message: 'This roll number has already submitted the exam' });
    } else {
      res.status(500).json({ success: false, message: error.message });
    }
  }
});

// Check if roll number exists
app.get('/api/check-roll/:rollNumber', async (req, res) => {
  try {
    const { rollNumber } = req.params;
    const [rows] = await pool.execute(
      'SELECT COUNT(*) as count FROM exam_responses WHERE roll_number = ?',
      [rollNumber]
    );
    res.json({ exists: rows[0].count > 0 });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get all exam responses (for admin)
app.get('/api/responses', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM exam_responses ORDER BY submitted_at DESC');
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get exam statistics
app.get('/api/stats', async (req, res) => {
  try {
    const [count] = await pool.query('SELECT COUNT(*) as total FROM exam_responses');
    const [avgScore] = await pool.query('SELECT AVG(score) as average FROM exam_responses');
    const [tabSwitches] = await pool.query('SELECT COUNT(*) as count FROM exam_responses WHERE was_tab_switched = 1');

    res.json({
      success: true,
      data: {
        totalSubmissions: count[0].total,
        averageScore: Math.round(avgScore[0].average * 100) / 100,
        tabSwitchCount: tabSwitches[0].count
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// ==================== QUESTION MANAGEMENT ENDPOINTS ====================

// Get all questions
app.get('/api/questions', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM exam_questions ORDER BY id ASC');
    // Parse options from JSON string
    const questions = rows.map(row => ({
      id: row.id,
      question: row.question,
      options: JSON.parse(row.options),
      correctAnswer: row.correct_answer
    }));
    res.json({ success: true, data: questions });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Add new question
app.post('/api/questions', async (req, res) => {
  try {
    const { question, options, correct_answer } = req.body;
    
    const query = `
      INSERT INTO exam_questions (question, options, correct_answer)
      VALUES (?, ?, ?)
    `;
    
    const [result] = await pool.execute(query, [
      question,
      JSON.stringify(options),
      correct_answer
    ]);
    
    res.json({ success: true, message: 'Question added successfully!', id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Update question
app.put('/api/questions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { question, options, correct_answer } = req.body;
    
    const query = `
      UPDATE exam_questions 
      SET question = ?, options = ?, correct_answer = ?
      WHERE id = ?
    `;
    
    await pool.execute(query, [
      question,
      JSON.stringify(options),
      correct_answer,
      id
    ]);
    
    res.json({ success: true, message: 'Question updated successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Delete question
app.delete('/api/questions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.execute('DELETE FROM exam_questions WHERE id = ?', [id]);
    res.json({ success: true, message: 'Question deleted successfully!' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log('Available endpoints:');
  console.log('  GET  / - Health check');
  console.log('  GET  /api/test - Test database connection');
  console.log('  POST /api/submit-exam - Submit exam response');
  console.log('  GET  /api/check-roll/:rollNumber - Check if roll number exists');
  console.log('  GET  /api/responses - Get all responses (admin)');
  console.log('  GET  /api/stats - Get exam statistics');
  console.log('  GET  /api/questions - Get all questions');
  console.log('  POST /api/questions - Add new question');
  console.log('  PUT  /api/questions/:id - Update question');
  console.log('  DELETE /api/questions/:id - Delete question');
});
